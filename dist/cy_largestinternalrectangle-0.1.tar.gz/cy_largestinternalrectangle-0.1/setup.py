from setuptools import setup, Extension
from Cython.Build import cythonize
import numpy as np

extensions = [
    Extension(
        "cy_largestinternalrectangle",  # Package path
        ["cy_largestinternalrectangle/largestinternalrectangle.pyx"],  # File location
        include_dirs=[np.get_include()],
        extra_compile_args=["-O3", "-march=native", "-ffast-math", "-fopenmp"],
        extra_link_args=["-fopenmp"],
    )
]

setup(
    name="cy_largestinternalrectangle",
    version="0.1",
    author="Nathan",
    author_email="nathan.tambeur@relu.eu",
    description="Fast Cython implementation for largest interior rectangle calculations.",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    ext_modules=cythonize(extensions, annotate=True, language_level=3),
    packages=["cy_largestinternalrectangle"],
    include_dirs=[np.get_include()],
    zip_safe=False,
)
